<template>
  <div>
    <h1>Mahsulotlar Ro'yxati</h1>
    <table>
      <thead>
      <tr>
        <th>Nomi</th>
        <th>Tavsifi</th>
        <th>Narxi</th>
        <th>Faollik</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="product in products" :key="product.id">
        <td>{{ product.name }}</td>
        <td>{{ product.description }}</td>
        <td>{{ product.price }} $</td>
        <td>{{ product.active ? 'Ha' : 'Yo\'q' }}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script>

import axios from "axios";

export default {
  data() {
    return {
      products: [],
    };
  },
  methods: {
    async fetchProducts() {
      try {
        // const response = await fetch('http://localhost:8081/api/product');
        const response = await axios.get("http://localhost:8081/api/product");

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }

        this.products = await response.json();

        console.log(this.products)
        console.log(response)

      } catch (error) {
        console.error('Fetch error:', error);
      }
    }
  },
  created() {
    this.fetchProducts();
  },
};
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  border: 1px solid #5a4e4e;
  padding: 8px;
  text-align: left;
}

th {
  background-color: #b81111;
}
</style>
